# ZendeskDirectcallAPP - Directcall APP

Funciona com telefone convencional ligado em qualquer linha telefônica (fixa, móvel ou IP), também em ramais DDR e IP, envio de SMS e Torpedo de Voz (TTS)

### Documentação:

http://doc.directcallsoft.com/pages/viewpage.action?pageId=55934980

### Informações adicionais:

http://directcall.com.br/produto/gestor-telecom/

# Desenvolvedor:

 - Directcall Telecom
 - Suporte <suporte@directcall.com.br>

